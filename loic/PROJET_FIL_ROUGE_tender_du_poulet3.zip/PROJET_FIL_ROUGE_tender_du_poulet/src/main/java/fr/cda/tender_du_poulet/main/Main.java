package fr.cda.tender_du_poulet.main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import fr.cda.tender_du_poulet.beans.Admin;
import fr.cda.tender_du_poulet.dao.AdminRepository;


public class Main {
	
	/*@Autowired
	private static AdminRepository repo;

	public static void main(String[] args) {

		String compte_admin = "testCompte";
		String mot_de_passe_admi = "testMdp";
		Admin a = new Admin(compte_admin, mot_de_passe_admi);
		repo.save(a);
		System.out.println(compte_admin + " " + mot_de_passe_admi);

	}*/

}
