package fr.cda.tender_du_poulet.metiers;

public class UtilisateurVerif {

}
