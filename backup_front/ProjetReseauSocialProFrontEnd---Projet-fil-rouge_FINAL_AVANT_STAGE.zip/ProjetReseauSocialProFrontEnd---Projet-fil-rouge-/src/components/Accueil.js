import React from "react";

function Accueil() {
  return (
     
      <div class="container">
        <div class="row align-items-center ">
          
         
            <h1 class="font-weight-light color-green">L'ECHANGE, NOTRE VOCATION</h1>
      

        </div>
       
    </div>
  );
}

export default Accueil;