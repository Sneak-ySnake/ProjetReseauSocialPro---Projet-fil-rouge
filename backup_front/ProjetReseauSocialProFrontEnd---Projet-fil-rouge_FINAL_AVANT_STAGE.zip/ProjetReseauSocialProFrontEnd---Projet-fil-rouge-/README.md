Dépendances à installer :

npm install react
npm install axios
npm install js-sha256