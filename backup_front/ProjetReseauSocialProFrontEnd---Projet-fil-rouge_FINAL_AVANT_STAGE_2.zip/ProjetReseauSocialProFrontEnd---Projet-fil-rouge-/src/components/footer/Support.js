import React from "react";

function Support() {
  return (
    <div className="Support">
      <div class="container">
        <div class="row align-items-center my-5">
          <div>
          </div>
          <div>
            <h1 class="font-weight-light">Support</h1>
            <p>En cours de construction</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Support;