import React from "react";

function NousContacter() {
  return (
    <div className="NousContacter">
      <div class="container">
        <div class="row align-items-center my-5">
          <div>
          </div>
          <div>
            <h1 class="font-weight-light">Nous contacter</h1>
            <p>En cours de construction</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default NousContacter;