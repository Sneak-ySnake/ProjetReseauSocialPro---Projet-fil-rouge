import React from "react"; 



class Filtrer extends React.Component {

    constructor() {
        super();
    
        this.state = {
         
        };
      }

      
    
  render(){ 
  
    return (
    
    
    <div class="container">
        <div class="row">
          <div class="col">
          <Negocier></Negocier>
          </div>
          <div class="col">
          <Negocier></Negocier>
          </div>
          <div class="col">
          <Negocier></Negocier>
          </div>
        </div>
    </div>
          
           
           
       
      );

    }
    
   };



export default Filtrer;